/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StockMarket;

/**
 *
 * @author admin
 */
public class Buy extends Order
{
    double Balance;
    public Buy(String name, double value, double balance)
    {
        super(name, value);
        Balance = balance;
    }

    public void Display()
    {
       System.out.println("Buy[super=Order[name = "+Name+" @, Price = "+Value+"]");
    }
}
