/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StockMarket;

/**
 *
 * @author admin
 */
public class Order
{
    double Value;
    String Name;
    public Order(String name, double value)
    {
        Name = name;
        Value = value;
    }   
    
    public void Display()
    {
        System.out.println( "Order[name = "+Name+" Current Price:, Price = "+Value+"]");
    }
}
