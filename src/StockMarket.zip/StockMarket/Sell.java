/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StockMarket;

/**
 *
 * @author admin
 */

public class Sell extends Order
{
    String Sector;
    public Sell(String name, double value, String sector)
    {
        super(name, value);
        Sector = sector;
    }

    public void Display()
    {
        System.out.println( "Sell[super=Order[name = "+Name+" @, Price = "+Value+"], Stock Market Sector = " + Sector);
    }
}
