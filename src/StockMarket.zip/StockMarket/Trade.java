/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StockMarket;

import java.util.Scanner;
/**
 *
 * @author MALIK
 */
public class Trade {
    
    
   
   
    
 
   
   /*  public double currentDow;
    public double closePriceDow;
    public double openPriceDow;
    public double lowPriceDow;  */
    
     public static Scanner s1 = new Scanner(System.in);
     public static Scanner s2 = new Scanner(System.in);
     public static Scanner s3 = new Scanner(System.in);
     public static String c;
     public static String d;
     public static int shares;
    public  void enterTrade()
    {
        wallStreet dowObject = new wallStreet();
        double dowd1=dowObject.currentDow;
        double dowd2=dowObject.closePriceDow;
        double dowd3=dowObject.openPriceDow;
        double dowd4=dowObject.lowPriceDow;
        int sharesdow=dowObject.numberofShares;
        wallStreet NasObject = new wallStreet();
        double nas1=NasObject.currentDow;
        double nas2=NasObject.closePriceDow;
        double nas3=NasObject.openPriceDow;
        double nas4=NasObject.lowPriceDow;
        int sharesnas=NasObject.numberofShares;
        wallStreet SpObject = new wallStreet();
        
        double sp1=SpObject.currentDow;
        double sp2=SpObject.closePriceDow;
        double sp3=SpObject.openPriceDow;
        double sp4=SpObject.lowPriceDow;
        int sharessp=SpObject.numberofShares;
        
       /* dowObject.currentPriceDow = d1;
        dowObject.openPriceDow = d2;
         dowObject.lowPriceDow = d3;
        */
      
        do{
        System.out.println("Please Enter name of the Comapany Dow,Nas,Sp");
        
     
       d = s3.nextLine();
        
          
        
        if(d.equalsIgnoreCase("dow")){
            System.out.println("Enter name Comapany Dow current Price");
            
             dowd1 = s2.nextDouble();
            
            //dowObject.currentDow = d;
            System.out.println("Enter name Comapany Dow close Price");
            
            dowd2=s2.nextDouble();
            
            System.out.println("Enter Comapany Dow Open Price");
            
           dowd3=s2.nextDouble();
            System.out.println("Enter name Comapany Dow low Price");
            
            dowd4=s2.nextDouble();
            System.out.println("Please Enter number of Shares ");
          
            sharesdow= s2.nextInt();
            
            if(dowd1 > dowd3 && dowd2 < dowd4){
                
                
                
                System.out.println("Your bought " + sharesdow + " Shares" + " each at $" +dowd1);
                System.out.println("Your total amount is $" + sharesdow*dowd1);
            }
            else if(dowd1 < dowd3 || dowd2 > dowd4){
                
                System.out.println("The Trade is  not process!. Pleae enter it again");
                
                
               System.out.println("Enter name Comapany Dow current Price");
            
             dowd1 = s2.nextDouble();
            
            //dowObject.currentDow = d;
            System.out.println("Enter name Comapany Dow close Price");
            
            dowd2=s2.nextDouble();
            
            System.out.println("Enter Comapany Dow Open Price");
            
           dowd3=s2.nextDouble();
            System.out.println("Enter name Comapany Dow low Price");
            
            dowd4=s2.nextDouble();
            
                System.out.println("Please Enter number of Shares ");
          
            shares= s2.nextInt();
                
                
                
            }
            
            
            System.out.println("do you want to continue? Y/N");
            c=s1.nextLine();
            
        }
        
        if(d.equalsIgnoreCase("nas")){
            System.out.println("Enter name Comapany NAS current Price");
            
             nas1 = s2.nextDouble();
           
            //dowObject.currentDow = d;
            System.out.println("Enter name Comapany NAS close Price");
            
            nas2 =s2.nextDouble();
            
            System.out.println(" Enter Comapany NAS Open Price");
            nas3=s2.nextDouble();
            System.out.println("Enter name Comapany NAS low Price");
            
            nas4=s2.nextDouble();
            
            System.out.println("Please Enter number of Shares ");
          
            sharesnas= s2.nextInt();
            if(nas1 > nas3 && nas2 < nas4){
                
                System.out.println("Your bought " +  sharesnas + " Shares" + " each at $" +nas1);
                System.out.println("Your total amount is $" + sharesnas*nas1);
            }
            else if(nas1 < nas3 || nas2 > nas4){
            
            System.out.println("The Trade is  not process!. Pleae enter it again");
           
            System.out.println("Enter name Comapany NAS current Price");
            
             nas1 = s2.nextDouble();
            
            //dowObject.currentDow = d;
            System.out.println("Enter name Comapany NAS close Price");
            
            nas2 =s2.nextDouble();
            
            System.out.println(" Enter Comapany NAS Open Price");
            nas3=s2.nextDouble();
            System.out.println("Enter name Comapany NAS low Price");
            
            nas4=s2.nextDouble();
            
            System.out.println("Please Enter number of Shares ");
          
            shares= s2.nextInt();
            
            }
            
            
            
            System.out.println("do you want to continue? Y/N");
            c=s1.nextLine();
            
        }
        
        
        if(d.equalsIgnoreCase("sp")){
            System.out.println("Enter name Comapany SP current Price");
            
             sp1 = s2.nextDouble();
            
            //dowObject.currentDow = d;
            System.out.println("Enter name Comapany SP close Price");
            
            sp2 =s2.nextDouble();
            
            System.out.println(" Enter Comapany SP Open Price");
            
            sp3=s2.nextDouble();
            System.out.println("Enter name Comapany SP low Price");
            
            sp4=s2.nextDouble();
            
            System.out.println("Please Enter number of Shares ");
          
            sharessp= s2.nextInt();
            
        }
        if(sp1 > sp3 && sp2 < sp4){
                
                System.out.println("Your bought " +  sharessp + " Shares" + " each at $" +sp1);
                System.out.println("Your total amount is $" + sharessp*sp1);
                
            }
          else  if(sp1 < sp3 || sp2 > sp4){
                
                System.out.println("The Trade is  not process!. Pleae ente it again");
                
                System.out.println("Enter name Comapany SP current Price");
                         sp1 = s2.nextDouble();
            
            //dowObject.currentDow = d;
            System.out.println("Enter name Comapany SP close Price");
            
            sp2 =s2.nextDouble();
            
            System.out.println(" Enter Comapany SP Open Price");
            
            sp3=s2.nextDouble();
            System.out.println("Enter name Comapany SP low Price");
            
            sp4=s2.nextDouble();
            System.out.println("Please Enter number of Shares ");
          
            shares= s3.nextInt();
            }
        
        System.out.println("do you want to continue? Y/N");
            c=s1.nextLine();
        
    }while(c.equalsIgnoreCase("y"));
        
    }
    
    
}