/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package StockMarket;

import java.util.Scanner;


public class wallStreet {
    
   
    public double currentDow;
    public double closePriceDow;
    public double openPriceDow;
    public double lowPriceDow;
    
    
    /*
    public void Dow(double cd, double cpd, double opd, double lpd){
        
        currentDow = cd;
        currentPriceDow = cpd;
        openPriceDow = opd;
        lowPriceDow = lpd;
                
    }
    */
    
    public double currentNas;
    public double closePriceNas;
    public double openPriceNas;
    public double lowPriceNas;
    
    public double currentSp;
    public double closePriceSp;
    public double openPriceSp;
    public double lowPriceSp;
    public int numberofShares;
   
    
    
    
    
 
public static void main(String[] args) {
    
   System.out.println("/*************************************" +"\n" +
"* Project Information " + "\n" + "Course : CSCI 185/504 Spring 2016" +"\n" +"*Project Name : StockMarket" +"\n"  + "*File Name: Project 1 "  + "\n" + "*Authon : Abdullah alhothali "+ "\n" +"* Date Created : 02/04/2016" + "\n"+ "* Data Updated : 02/10/2016 There are");
    
   
   System.out.print("some changes for the class wallStreet" + "\n" + "where a new class or variable has been" + "\n" + "added." + "\n" + "*Description : This project will allow" + "\n"+ "the user to enter his choice and" +"\n" +"select his company to trade with (Dow" +"\n"+"Joend, NASDAQ, and S&P 500)" +"\n" + "*" +"\t" + "The project will print"+"\n"+ "out the number of shares and the"+ "\n"+ "total price." + "\n" + "*************************************" +"\n"+ "*************************************" +"\n"+ "*************************************");
   
   
   System.out.println("\n"+"*********************/");
   
   System.out.println("Welcome to the MarkePlace ");
   
    //marketPlace();
        double purchase;
        Scanner kb = new Scanner (System.in);
        System.out.println("Enter the number of shares you wish to buy for AAPL: ");
        int shares = kb.nextInt(); 
  
    Order oObj = new Order("AAPL",250);
        Buy bObj = new Buy("AAPL",185,9999);
        Sell sObj = new Sell("AAPL",230,"Technology");
        oObj.Display();
        bObj.Display();
        sObj.Display();
        purchase = shares * oObj.Value;

        if(purchase > bObj.Balance)
            System.out.println("Your order is  cancelled.");
        else
            System.out.println("Your order is accepted.");

        //End of project 2
}


public static void marketPlace(){
    
   Trade t = new Trade();
   t.enterTrade();
}
}
